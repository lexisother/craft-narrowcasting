-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB-1:10.4.28+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_flntzfezyqfqjyfzrzhxcyoilyiahgcieqov` (`ownerId`),
  CONSTRAINT `fk_dzxtygmvrmdxwnsdwulyicdfcknfjjujxsim` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_flntzfezyqfqjyfzrzhxcyoilyiahgcieqov` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_plwglemsnazkewddfyzorhskzrjirpatfrda` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_njllrjdvyrzonlpvqerhnpjfsjutovoybfuz` (`dateRead`),
  KEY `fk_hdawirasmmpkkytnuzzxkbforuwfvvbbnvfz` (`pluginId`),
  CONSTRAINT `fk_hdawirasmmpkkytnuzzxkbforuwfvvbbnvfz` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pcuxeojlsjrovpqbkqlupqzwtdnfwqbizexe` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_akcxjabtxyxaqxybmthlrbtwbtjxjwjsdpte` (`sessionId`,`volumeId`),
  KEY `idx_rfgafmernwsiascfyelxseftrclgumpxnumq` (`volumeId`),
  CONSTRAINT `fk_tlkvhzvtltjfykqxbjwdnmrimqzbqmpcypbz` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xcmjtfljdiyiesgkwnshbopjwmeeqbdzeysw` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT 0,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `processIfRootEmpty` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_eidxlwsvbsphoifkwjpwziyzvddzruuamecv` (`filename`,`folderId`),
  KEY `idx_echoudgruihnvgfeoxcymkukbxysqhlwiczw` (`folderId`),
  KEY `idx_bpizuymdcyaffidxqkwvnmsqcrfqsjokztca` (`volumeId`),
  KEY `fk_mcylubuvdfweomcislkyynpcifewoccrkohm` (`uploaderId`),
  CONSTRAINT `fk_bewuuoejflrmfttswdbkgmnhtuxzkfrxkycs` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mcylubuvdfweomcislkyynpcifewoccrkohm` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ozizjiwbiegocjmuvrpnoztcfbaxzviqwbgf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vcobnxqwnrakrahbzreffdqjywplncrepmbh` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_beqwvgbmsjfnvrkazmxjykfqokohgdtnxime` (`groupId`),
  KEY `fk_zbzaxmdrxzylhjmojyybkafwjhdiqkgouitv` (`parentId`),
  CONSTRAINT `fk_pzrnoumwjeashwxxrujylvipahbmvdadharl` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uhfzazvbiywyteybxjmrakusdlhadqavgajh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zbzaxmdrxzylhjmojyybkafwjhdiqkgouitv` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kvccsnwdivasyrvcisjvvqgsnrcjtlgfvaaa` (`name`),
  KEY `idx_hwxiejegvbejdaofehdektegiomjanfvgaif` (`handle`),
  KEY `idx_zlzdknerqgkksapsnyednnqcptubjoxigoeq` (`structureId`),
  KEY `idx_xnjoewhokauhnewjikzoeicbblnmiyonrdrd` (`fieldLayoutId`),
  KEY `idx_yefwpnxvjmaiotjlbvepnvnaobkrzrabdqqf` (`dateDeleted`),
  CONSTRAINT `fk_cpyhahmfbrikzgfiejhloivtvozdspxtpwox` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lqqccsflfersqhuhlugcfnyjcvmspkssjbfg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bkqhwfiozxfkopvpnskgqjutkwxwskuirkro` (`groupId`,`siteId`),
  KEY `idx_iegyasinfeamdykkvyvmvebuuzjqpgyjsorh` (`siteId`),
  CONSTRAINT `fk_rtyflizkzagubnypfmbfvijxzpxavyupjsbo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tjzgcjbqimbowxstqotmraroumvnsmvwxcbn` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_lsnvazizppjxoeqpqmvfmsucppyndgpspziq` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_aaalleiysrstooqfkabqchczctpqcwzbzuwc` (`siteId`),
  KEY `fk_kvhmetyzjjaoieomqsoufrobbtikyuvzuztw` (`userId`),
  CONSTRAINT `fk_aaalleiysrstooqfkabqchczctpqcwzbzuwc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kvhmetyzjjaoieomqsoufrobbtikyuvzuztw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_nmuoqvwwotcybtexgtwkqoezmeexvzgrmmwv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (2,1,'fieldLayoutId','2023-05-05 08:45:41',0,1),(2,1,'postDate','2023-05-05 08:45:48',0,1),(2,1,'slug','2023-05-05 08:45:48',0,1),(2,1,'title','2023-05-05 08:45:45',0,1),(2,1,'typeId','2023-05-05 08:45:41',0,1),(2,1,'uri','2023-05-05 08:45:48',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_zghugrmmjcscsxykdxapelyfaxdtnwnuoojw` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_juspijrwicjxtohtgzyvubhxscqrzqvjyckp` (`siteId`),
  KEY `fk_pvituwmakchnkrjgohfkywaxvmvvhfzqugmp` (`fieldId`),
  KEY `fk_oywwejcjbehfnnlgcmsqimlafhgpscvdxaeo` (`userId`),
  CONSTRAINT `fk_chyxesnjpdweueqxkiseeqovwzmdhhhhelub` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_juspijrwicjxtohtgzyvubhxscqrzqvjyckp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oywwejcjbehfnnlgcmsqimlafhgpscvdxaeo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pvituwmakchnkrjgohfkywaxvmvvhfzqugmp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,1,'2023-05-05 08:45:48',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tvionszlksbrkdnvyjanxoiqqnxsquffncpd` (`elementId`,`siteId`),
  KEY `idx_ofecpbdartgjnibqznvwnrcnpcnmyrcrymqz` (`siteId`),
  KEY `idx_vuvgdtpkemnazjzjmopiiaczzfivwetgelqp` (`title`),
  CONSTRAINT `fk_ppggxgqjgtyjxhesaeguaxooutxjhbyxjxdd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdzrjfkfjyvpbxrfdreqrocbpzmnshofxdqt` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2023-05-05 08:45:00','2023-05-05 08:45:00','f76f2969-650f-42d2-bd4f-88d39c57a8cc'),(2,2,1,'test','2023-05-05 08:45:37','2023-05-05 08:45:48','486c8988-0908-4298-882e-8fedf4dec683'),(3,6,1,'test','2023-05-05 08:45:48','2023-05-05 08:45:48','33b5a56c-39ed-4a74-8e9d-f41ff3567ae9');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_jsmbeawulgyoamwadwduqnjshejkpznluxze` (`userId`),
  CONSTRAINT `fk_jsmbeawulgyoamwadwduqnjshejkpznluxze` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kqvacyjufekdjiiytqvsatijkikgbwgfofre` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_aluverfonsgpmrzyqwdxjcvlvtgpripgzksi` (`creatorId`,`provisional`),
  KEY `idx_zxmidaatabdvhkecltowffbitwmncyablvid` (`saved`),
  KEY `fk_zosjuixxlyoitbpdnkzpuhzqabxsooerzwjp` (`canonicalId`),
  CONSTRAINT `fk_bujkfubxqdhohnokhokxlqowdskefyevyetf` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zosjuixxlyoitbpdnkzpuhzqabxsooerzwjp` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_htgfzxtyqqnyzpxgmmwsoakodrcxqebkksnt` (`dateDeleted`),
  KEY `idx_rzkhqewkxddweehqcysqhidfwkquimxtctds` (`fieldLayoutId`),
  KEY `idx_caqvpjnjzeckwjrqvlstzhedzowlbtvoqets` (`type`),
  KEY `idx_jrvzjofjexgejkagpjfbcewzjyqbdyokwazm` (`enabled`),
  KEY `idx_sastobjycibtpkbqzhengeiircgsmmzfiyye` (`archived`,`dateCreated`),
  KEY `idx_denodihvqqjgpgoyspfjziaqfzmbsvebowou` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_xffmjuvrjzkpblhpdupgczkvlybmskqjxhtj` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ylwurwogkknbjtafjqkgjdhqfpybxrijhwzl` (`canonicalId`),
  KEY `fk_syztocdppariftbuqhpkwueuhbcsdvgrsore` (`draftId`),
  KEY `fk_balalwtbmubxljchwbqxzvbxnnhjaftynruz` (`revisionId`),
  CONSTRAINT `fk_balalwtbmubxljchwbqxzvbxnnhjaftynruz` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_isvwmluvdchvjvgtjhnmdckyaruwylmlrtrv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_syztocdppariftbuqhpkwueuhbcsdvgrsore` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ylwurwogkknbjtafjqkgjdhqfpybxrijhwzl` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-05-05 08:45:00','2023-05-05 08:45:00',NULL,NULL,'a1a9a7e8-8904-4fbc-ad8d-a56f7687a2df'),(2,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-05-05 08:45:37','2023-05-05 08:45:48',NULL,NULL,'a4a73c58-33b6-4d0f-b43f-f7e69babc003'),(3,NULL,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2023-05-05 08:45:45','2023-05-05 08:45:45',NULL,'2023-05-05 08:45:47','d059fecd-7bd8-4404-9dcf-349d40ffd8c5'),(4,NULL,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2023-05-05 08:45:47','2023-05-05 08:45:47',NULL,'2023-05-05 08:45:48','83f7423f-e022-4878-b623-3038747d3023'),(5,NULL,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2023-05-05 08:45:48','2023-05-05 08:45:48',NULL,NULL,'ef053a11-0cc2-4d77-879e-9b7119551949'),(6,2,NULL,1,2,'craft\\elements\\Entry',1,0,'2023-05-05 08:45:48','2023-05-05 08:45:48',NULL,NULL,'0eb4cb42-020f-4d22-9e67-03320fa75fed'),(7,5,NULL,2,5,'craft\\elements\\MatrixBlock',1,0,'2023-05-05 08:45:48','2023-05-05 08:45:48',NULL,NULL,'82e83769-6d66-4093-80a6-863429d0dec1');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yflkfagwaktdvwegwlfsjgwrptiwjdbtuorl` (`elementId`,`siteId`),
  KEY `idx_jqxbbiyxskbworjqbyaylmmikrkjoiorfpce` (`siteId`),
  KEY `idx_yzsgyqvorkgohobisersimowtdjqkdxhjoaz` (`slug`,`siteId`),
  KEY `idx_qiwuhzmsnztwzqdulcelteyenkkwpubynwvk` (`enabled`),
  KEY `idx_potezybzhogzoqtyyhsgadvtibwrecuszaco` (`uri`,`siteId`),
  CONSTRAINT `fk_uvnvhpjymodpgwspgzmpssqxiugnbmllngrx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zadejcieqmpugljqcdgmvdpyskfvzqetkfbz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2023-05-05 08:45:00','2023-05-05 08:45:00','6a157887-31d3-4053-9952-0fa6f9ee3daf'),(2,2,1,'test','narrowcasting/test',1,'2023-05-05 08:45:37','2023-05-05 08:45:48','ab9df556-dd4b-47b6-98e2-797d148b4c1b'),(3,3,1,NULL,NULL,1,'2023-05-05 08:45:45','2023-05-05 08:45:45','dd1d0e65-af83-43f2-985a-54af13b97cc9'),(4,4,1,NULL,NULL,1,'2023-05-05 08:45:47','2023-05-05 08:45:47','4291d080-89fc-4d08-9b52-cc8bf7503e73'),(5,5,1,NULL,NULL,1,'2023-05-05 08:45:48','2023-05-05 08:45:48','3302e3ae-a9cb-4b34-a254-ba5202192620'),(6,6,1,'test','narrowcasting/test',1,'2023-05-05 08:45:48','2023-05-05 08:45:48','d6e9b300-5adc-418b-8216-7f937da9049d'),(7,7,1,NULL,NULL,1,'2023-05-05 08:45:48','2023-05-05 08:45:48','9c8c77d0-0a02-473a-b8f2-c5f977a04785');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zvstvxgglnvmunuvvhciryvdiwskplzpftvy` (`postDate`),
  KEY `idx_ucdslpvfnsbydanzvgevahgfhztoqjvlkxqq` (`expiryDate`),
  KEY `idx_pyxdonnykfmjivomxyoucxhnmosylvoabcpe` (`authorId`),
  KEY `idx_bnbgckqsbmnlhnwyckibxoohcrffscimmzyh` (`sectionId`),
  KEY `idx_znlkougrpkxbeamfpqcodpsichxjsrvlvztj` (`typeId`),
  KEY `fk_qggmebohbfwjthnbrvpjahurxgfhtcjhaxtu` (`parentId`),
  CONSTRAINT `fk_dlewjumvrvwgewytuzlnjrnrzvgqqnkwjhdh` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fyleenfmjzhavdbvestrttbmcyxaweelzkwg` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lpcnhrufmwytbkiurtxfmpbusiadbiqtmgmy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mmzgsslvuqvkkdqvgfxhkhgchqvztrtyjmmn` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qggmebohbfwjthnbrvpjahurxgfhtcjhaxtu` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,2,1,'2023-05-05 08:45:00',NULL,NULL,'2023-05-05 08:45:37','2023-05-05 08:45:48'),(6,1,NULL,2,1,'2023-05-05 08:45:00',NULL,NULL,'2023-05-05 08:45:48','2023-05-05 08:45:48');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hkvncljtbdlrxmlupqmkdcvyziqfsbxxompf` (`name`,`sectionId`),
  KEY `idx_kjmxyospxsgafwfkcutjyukkpeorrrascjnc` (`handle`,`sectionId`),
  KEY `idx_hbsxclazomzkpslxhobnurescqzpihlqbjhs` (`sectionId`),
  KEY `idx_uolyfpwgxkehtczugkbqxdfxnqjxaoqaafbi` (`fieldLayoutId`),
  KEY `idx_qettgtugxcabrvtnjkxoxaptslnxripikpbf` (`dateDeleted`),
  CONSTRAINT `fk_odutbmmjyyngxtkpyhmuwdhhypikclfpdedt` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ohwgliqnpqnzcqursdiwztspksjnnaxqvxsg` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,1,'2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'4e315b8e-e012-4f17-818b-a5b0c6189d80'),(2,1,2,'Slides','slides',1,'site',NULL,NULL,2,'2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'d33c5983-4dff-4b6a-9aaa-7128c8c7c889');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xezmirxuehfdzdidkpjefshpzkcnvdlhczxo` (`name`),
  KEY `idx_cyspipuduoucjrzskkpfbzyemtssxsdozopi` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'9d29337f-6b3e-47b2-8ff0-aaf4151cda6d');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fsjyclqajkecwajqludcqmtiodnghgzlaexo` (`layoutId`,`fieldId`),
  KEY `idx_gacmjsnfrepeqxprykdlsyvjlcddneyecgil` (`sortOrder`),
  KEY `idx_vrwvuapqwdpwrlkjcppeawbajqyikxihfekf` (`tabId`),
  KEY `idx_lbmyktjaclpamdhoglxgxojxnpoabuhsqvgv` (`fieldId`),
  CONSTRAINT `fk_gshrbrmofpqkffhvlxceekolhpifupvwqqxf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_itbwbooostoswvanuyexjgexxxvzgsocuztx` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wvxtzxfrqywxbsqeghrdhluglwvfzwndudfw` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (18,2,14,1,0,1,'2023-05-05 08:44:59','2023-05-05 08:44:59','abe0ee2d-dc56-4e62-8b30-026ccc04321a'),(23,4,18,5,1,0,'2023-05-05 08:44:59','2023-05-05 08:44:59','8ef5fc46-831a-4c50-879b-9620e036384a'),(24,4,18,2,1,1,'2023-05-05 08:44:59','2023-05-05 08:44:59','06e944c5-43af-4b96-8d20-eac106375a4a'),(25,4,18,3,0,2,'2023-05-05 08:44:59','2023-05-05 08:44:59','4ddd17c8-fe6a-44fc-a33a-56da725ab8e8'),(26,4,18,4,0,3,'2023-05-05 08:44:59','2023-05-05 08:44:59','d113abe5-c2ac-4d14-a073-2f1124b8264b'),(30,5,20,6,1,0,'2023-05-05 08:44:59','2023-05-05 08:44:59','d67a1768-69a1-4090-8e65-06af8e09909e'),(31,5,20,8,0,1,'2023-05-05 08:44:59','2023-05-05 08:44:59','d6e8bedc-fc48-4015-8d35-47dc52fd7e77'),(32,5,20,7,0,2,'2023-05-05 08:44:59','2023-05-05 08:44:59','d09c527e-c6e1-46b8-9c43-2f2cd6454477'),(36,6,24,9,1,0,'2023-05-05 08:45:00','2023-05-05 08:45:00','bea0957a-1a92-4344-a7ef-3e6a91a1abb4');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_talqmgpzvhctryjuhpsdidocyoszhjashylg` (`dateDeleted`),
  KEY `idx_rvqweoujlpzfxhmskksfiozkfoxwggdwxuil` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'c0a16fbb-65e4-4d29-839b-b1c280941d77'),(2,'craft\\elements\\Entry','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'d159507e-00ee-4186-89ce-aa8d13c0f551'),(3,'craft\\elements\\Asset','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'77272be3-f4fe-4f09-828e-8045257df5d4'),(4,'craft\\elements\\MatrixBlock','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'a89b9c73-7077-4bce-bbe6-86a9fb3c27b5'),(5,'craft\\elements\\MatrixBlock','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'8799252d-cba1-4d22-9a19-aaa5857df6b1'),(6,'craft\\elements\\MatrixBlock','2023-05-05 08:45:00','2023-05-05 08:45:00',NULL,'a99dcfd0-e437-4f43-b3ef-3242bbcc8338');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_agrxgfcrtyjwnauhlyxqgvaqcgqbfdqqqjzj` (`sortOrder`),
  KEY `idx_syweudxoifxpmklnbjjpqhezrehgboklvknh` (`layoutId`),
  CONSTRAINT `fk_rggaxqjmfpqhxgqwheczxscrhejmavinylsl` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (12,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"ec848039-61b3-4cd0-8c02-c391d2689421\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','dca6fffc-645c-49f0-9467-0f2d5aee2a69'),(14,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"f3b2ba6d-b575-4f39-b525-17d300b870b9\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"ef0f778b-85df-48a3-884b-c7a0a32e3d23\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2fe47f5e-f465-4d4b-bafc-db94fcd20d62\"}]',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','c25aac81-6e27-41ae-a7ca-c390a8be1619'),(16,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"b11e089d-1b17-426d-8684-cd41a2511048\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','45efbd87-93d5-42cf-8e3a-4ad101f90169'),(18,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"5d80b760-b308-4735-b3ae-a654aba3aa36\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ce2c8583-c7bf-4d08-b9a0-cf6557c1d401\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"6e5de58d-c553-402a-8e60-a74642a9dfa8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9eb78600-e611-43fc-9c72-f7ee4d188cee\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"990b24e3-1b70-41c6-acbc-09e00dcc4dfb\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1d964b7f-09b0-4b5b-b458-512db536397c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a27b6d9b-05b5-46d6-aa08-6094d75094f2\"}]',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','29e65fe4-8cf0-4416-860d-04226248aedb'),(20,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"31aaa4e0-fcf9-46d7-8a88-1f5a64b60ccd\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0ceb5003-324b-47f9-b336-5716ff21c825\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"375fcf49-f25e-4b97-97ca-38d23bb1ed5a\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a7316bd8-0e45-41fb-bad7-6e74a6f2a902\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"2a098051-16ec-4052-a9f8-ce674e172a7b\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"2928f6e5-130a-431d-a1f3-df296cd1f46a\"}]',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','c1d68812-8393-416d-8cd8-6d14a80dcc7d'),(24,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"746ecfa6-abeb-4506-8c73-765c5537f001\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ee5459e3-ec14-4342-9e3a-fc007e6a5238\"}]',1,'2023-05-05 08:45:00','2023-05-05 08:45:00','a97509a6-f1c1-49e8-b31b-af26952b62e9');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hctmgjgjqbaopcoqnhkhponzlrukfywfwfpd` (`handle`,`context`),
  KEY `idx_pkprelrjozscjeaocfbgmgtntzdnvbxkqqhm` (`groupId`),
  KEY `idx_kfogyogjvvczkubzqpvhqpjrbvazwsrytehl` (`context`),
  CONSTRAINT `fk_kyqrvoawpbizhgcnqalypfvfrginkgoigpis` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,1,'Narrowcasting Slides','narrowcastingSlides','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_narrowcastingslides}}\",\"maxBlocks\":null,\"minBlocks\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','2fe47f5e-f465-4d4b-bafc-db94fcd20d62'),(2,NULL,'Media','media','matrixBlockType:34848ad2-3bb8-49fa-8f0a-bb4f69d4881d',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"defaultUploadLocationSource\":\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','9eb78600-e611-43fc-9c72-f7ee4d188cee'),(3,NULL,'Background Colour','backgroundColour','matrixBlockType:34848ad2-3bb8-49fa-8f0a-bb4f69d4881d','jsllqrnf',NULL,0,'none',NULL,'craft\\fields\\Color','{\"defaultColor\":\"#ffffff\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0'),(4,NULL,'Text Colour','textColour','matrixBlockType:34848ad2-3bb8-49fa-8f0a-bb4f69d4881d','onvjezyq',NULL,0,'none',NULL,'craft\\fields\\Color','{\"defaultColor\":\"#000000\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','a27b6d9b-05b5-46d6-aa08-6094d75094f2'),(5,NULL,'Text','text','matrixBlockType:34848ad2-3bb8-49fa-8f0a-bb4f69d4881d','btsjqgtw',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','ce2c8583-c7bf-4d08-b9a0-cf6557c1d401'),(6,NULL,'Text','text','matrixBlockType:d5eac6f2-f301-4348-b212-c25460e2b3d9','nlujdhmf',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','0ceb5003-324b-47f9-b336-5716ff21c825'),(7,NULL,'Text Colour','textColour','matrixBlockType:d5eac6f2-f301-4348-b212-c25460e2b3d9','tiyqvwsy',NULL,0,'none',NULL,'craft\\fields\\Color','{\"defaultColor\":\"#000000\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','2928f6e5-130a-431d-a1f3-df296cd1f46a'),(8,NULL,'Background Colour','backgroundColour','matrixBlockType:d5eac6f2-f301-4348-b212-c25460e2b3d9','wrwllbxa',NULL,0,'none',NULL,'craft\\fields\\Color','{\"defaultColor\":\"#ffffff\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','a7316bd8-0e45-41fb-bad7-6e74a6f2a902'),(9,NULL,'Media','media','matrixBlockType:928623f8-903d-4bb2-bb3e-c2b71c6d8b1d',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"defaultUploadLocationSource\":\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\",\"conditionRules\":[{\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\FileTypeConditionRule\",\"uid\":\"9ed4a011-9832-4d4f-8d25-98368742d7b0\",\"operator\":\"in\",\"values\":[\"image\",\"video\"]}]},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2023-05-05 08:44:59','2023-05-05 08:44:59','ee5459e3-ec14-4342-9e3a-fc007e6a5238');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ugzqwcfwsahrkokbqtzavhgrufskekxmynmo` (`name`),
  KEY `idx_hnovxrfogrkxsjticdisdqgattrnivvjgsgf` (`handle`),
  KEY `idx_ymirjsuzlwqjtplpwuqsucmrnucpkysqpkgu` (`fieldLayoutId`),
  KEY `idx_jtmgrsrkyeiscasrnnqnaqlagzlaqybmtcqy` (`sortOrder`),
  CONSTRAINT `fk_ehoybiaibcefdikztzfejpsqamhbuqcnwhtq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rqdkjxgvwtwuungbpczhrlvxylywnwnurgep` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[\"sections.9c11c497-5e71-4c81-afd3-317c35414085:read\",\"entrytypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889:read\",\"volumes.3ed0cc78-6b93-46f3-868e-46554089d28f:read\"]',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','adf70b30-6427-4956-b57f-e58fd68c05e9');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_emgwjqkheevpszhleotokfthvxtegkiqbamv` (`accessToken`),
  UNIQUE KEY `idx_ehtialghfejmshokilrkrkfrjnrwmudyapxf` (`name`),
  KEY `fk_zzaesimfmvqmompdjpwnfyvpvymqyoiwodoq` (`schemaId`),
  CONSTRAINT `fk_zzaesimfmvqmompdjpwnfyvpvymqyoiwodoq` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
INSERT INTO `gqltokens` VALUES (1,'Public Token','__PUBLIC__',1,NULL,'2023-05-05 09:02:50',NULL,'2023-05-05 08:48:42','2023-05-05 09:02:50','e57a4869-97cc-4582-a68e-78096dc8fa1e');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_peuarrtqlartcvymaxdznmdhyorrfzvhxtpb` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT 1,
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_amtlmlutszvoboglcpxqzpualqrezcxjjooh` (`name`),
  KEY `idx_aoupifluoairocitltjlkgoesqkxplrnuegn` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.4.9','4.4.0.4',0,'zqvryggxmwji','3@jzmzzygird','2023-05-05 08:44:59','2023-05-05 09:13:49','f9114f7e-9fa5-4bb2-8745-aa84c241afb3');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_inhmzdvuqulqicvkjjanphitknvvwjpeancv` (`primaryOwnerId`),
  KEY `idx_fruvwrezeehagdcxehiuedascvinizumwiqw` (`fieldId`),
  KEY `idx_sfoeiwovbgljidubfhjlcjkscntgejbcdyhx` (`typeId`),
  CONSTRAINT `fk_ayrssjyhrbjbetrqmahgwlkvbbvgslagggim` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nlcfdfevhwlgcrwhvufnprktkitqgceocxtg` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjrglgpuzqcqeoqliyprhavwagwtwjkbwyns` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvcxygjillbwvyxjjxwfouqkxxihipwvjwol` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
INSERT INTO `matrixblocks` VALUES (3,2,1,2,0,'2023-05-05 08:45:45','2023-05-05 08:45:45'),(4,2,1,2,0,'2023-05-05 08:45:47','2023-05-05 08:45:47'),(5,2,1,2,NULL,'2023-05-05 08:45:48','2023-05-05 08:45:48'),(7,6,1,2,NULL,'2023-05-05 08:45:48','2023-05-05 08:45:48');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_xzcmiuzalekrewnxtyhyybagnxwylaxzunqy` (`ownerId`),
  CONSTRAINT `fk_vzttibeorlyscqvbsyglflzprofzvcpminmf` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xzcmiuzalekrewnxtyhyybagnxwylaxzunqy` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
INSERT INTO `matrixblocks_owners` VALUES (3,2,1),(4,2,1),(5,2,1),(7,6,1);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pixdmohwyopvgpghzqahuqgjivhlgbgpirnq` (`name`,`fieldId`),
  KEY `idx_xnpizbkymlxcbgyittgksgkffkyzrlihtyta` (`handle`,`fieldId`),
  KEY `idx_scvxplokhtjjeglkpglloohomuireweolqfw` (`fieldId`),
  KEY `idx_bkdvzjtsfhfvtunomjrcsvisoqakanhrxnlx` (`fieldLayoutId`),
  CONSTRAINT `fk_llaoxlmhtisbfvagbsrbddzrgrthqhxtvhzo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ndarbqfeffimolvftabsebgylgfblwratxjk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
INSERT INTO `matrixblocktypes` VALUES (1,1,4,'Text & Media slide','textMedia',3,'2023-05-05 08:44:59','2023-05-05 08:44:59','34848ad2-3bb8-49fa-8f0a-bb4f69d4881d'),(2,1,5,'Text slide','text',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','d5eac6f2-f301-4348-b212-c25460e2b3d9'),(3,1,6,'Media slide','media',2,'2023-05-05 08:45:00','2023-05-05 08:45:00','928623f8-903d-4bb2-bb3e-c2b71c6d8b1d');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixcontent_narrowcastingslides`
--

DROP TABLE IF EXISTS `matrixcontent_narrowcastingslides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_narrowcastingslides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_textMedia_backgroundColour_jsllqrnf` varchar(7) DEFAULT NULL,
  `field_textMedia_textColour_onvjezyq` varchar(7) DEFAULT NULL,
  `field_textMedia_text_btsjqgtw` text DEFAULT NULL,
  `field_text_text_nlujdhmf` text DEFAULT NULL,
  `field_text_textColour_tiyqvwsy` varchar(7) DEFAULT NULL,
  `field_text_backgroundColour_wrwllbxa` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wbkbdbtvcmosowjuqltwhvnlbrcbfrchzlkj` (`elementId`,`siteId`),
  KEY `fk_jyghczyspgkcqebulgmxjsuzmxijyaktprqc` (`siteId`),
  CONSTRAINT `fk_jyghczyspgkcqebulgmxjsuzmxijyaktprqc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ppwkxujtkdgejiifscubdtmsovncinjyfjyw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixcontent_narrowcastingslides`
--

LOCK TABLES `matrixcontent_narrowcastingslides` WRITE;
/*!40000 ALTER TABLE `matrixcontent_narrowcastingslides` DISABLE KEYS */;
INSERT INTO `matrixcontent_narrowcastingslides` VALUES (1,3,1,'2023-05-05 08:45:45','2023-05-05 08:45:45','7bedfbdd-0c65-4cd0-95cf-e491eea9d73e',NULL,NULL,NULL,NULL,'#000000','#ffffff'),(2,4,1,'2023-05-05 08:45:47','2023-05-05 08:45:47','c8371007-a2f9-4ee8-b09f-b7831d954ae0',NULL,NULL,NULL,'helo','#000000','#ffffff'),(3,5,1,'2023-05-05 08:45:48','2023-05-05 08:45:48','78600c10-f87e-46a1-8484-0a1bb3a6df60',NULL,NULL,NULL,'helo','#000000','#ffffff'),(4,7,1,'2023-05-05 08:45:48','2023-05-05 08:45:48','825e7f17-afde-421b-b55a-01f00db258ac',NULL,NULL,NULL,'helo','#000000','#ffffff');
/*!40000 ALTER TABLE `matrixcontent_narrowcastingslides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vashdqezqiwbamobjkfllkrdwpykoywufwyf` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'plugin:redactor','m180430_204710_remove_old_plugins','2023-05-05 08:44:59','2023-05-05 08:44:59','2023-05-05 08:44:59','0086c27f-1457-4716-9313-1b953fe5e7d5'),(2,'plugin:redactor','Install','2023-05-05 08:44:59','2023-05-05 08:44:59','2023-05-05 08:44:59','f987ef4c-15ce-44e1-8351-6a8e65e145ac'),(3,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2023-05-05 08:44:59','2023-05-05 08:44:59','2023-05-05 08:44:59','8dc8a628-56f0-4f43-8b04-f021e5f040c5'),(4,'craft','Install','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','1237e655-21a6-40ee-ae6f-ad9eb89616cf'),(5,'craft','m210121_145800_asset_indexing_changes','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','93baf18f-6b33-4cac-b5a5-53519521a2f1'),(6,'craft','m210624_222934_drop_deprecated_tables','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','8a292b93-2921-46b5-87cc-54b05b609f10'),(7,'craft','m210724_180756_rename_source_cols','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','0f01cb65-b170-425c-832c-69978cfa113c'),(8,'craft','m210809_124211_remove_superfluous_uids','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','e02c270e-6cd2-42f5-8af0-cb09c27b1776'),(9,'craft','m210817_014201_universal_users','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','2a683c73-956b-4d7c-91e1-5340d361ffb5'),(10,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','069d217e-d62c-4253-a550-60e573c57890'),(11,'craft','m211115_135500_image_transformers','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','eedfe80f-29b5-40d4-8b0e-06247d08ede4'),(12,'craft','m211201_131000_filesystems','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','7e701706-4604-42ab-8dc9-40535011a4be'),(13,'craft','m220103_043103_tab_conditions','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','dbc51059-375e-4c0b-a47b-f7937ff01d64'),(14,'craft','m220104_003433_asset_alt_text','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','7ca51da2-34ac-4b27-845a-9cb439dcef13'),(15,'craft','m220123_213619_update_permissions','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','3d2ed2b5-9af2-44d9-8866-bae2a56ef7b5'),(16,'craft','m220126_003432_addresses','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','e5f09564-7822-41fb-affc-7f56a04879f7'),(17,'craft','m220209_095604_add_indexes','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','975b1668-e164-4d71-ab3e-01795ab9cf14'),(18,'craft','m220213_015220_matrixblocks_owners_table','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','22486c51-bae6-406f-8595-04b085ee2f8a'),(19,'craft','m220214_000000_truncate_sessions','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','86dec853-78a5-4d70-bc9e-f9cfb73441a5'),(20,'craft','m220222_122159_full_names','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','4162e64c-b1b5-405c-a428-0debb96fdcec'),(21,'craft','m220223_180559_nullable_address_owner','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','e2fe89bc-08ba-4724-8e6b-386d3b256d03'),(22,'craft','m220225_165000_transform_filesystems','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','b9b8876a-ed0b-4111-a7c5-b07567165931'),(23,'craft','m220309_152006_rename_field_layout_elements','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','7960ef25-7a54-4615-bcb9-8fb247e94c1c'),(24,'craft','m220314_211928_field_layout_element_uids','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','4c8acb8a-39c8-460a-8be5-b610686860a5'),(25,'craft','m220316_123800_transform_fs_subpath','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','0f587cb8-d0e3-4005-966c-3a05ffd9d4fd'),(26,'craft','m220317_174250_release_all_jobs','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','4004bb45-b3e8-4b98-a24c-f46e555da164'),(27,'craft','m220330_150000_add_site_gql_schema_components','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','a76e9ac3-6680-4995-b03a-52ef08cfdf47'),(28,'craft','m220413_024536_site_enabled_string','2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:00','d5e60bdc-483f-42b1-8349-f91d717b4d75'),(29,'craft','m221027_160703_add_image_transform_fill','2023-05-05 09:13:49','2023-05-05 09:13:49','2023-05-05 09:13:49','a873a115-041e-4b43-9e01-d49cd0605368'),(30,'craft','m221028_130548_add_canonical_id_index','2023-05-05 09:13:49','2023-05-05 09:13:49','2023-05-05 09:13:49','a0846da5-4668-4df9-bafc-79315fb622f1'),(31,'craft','m221118_003031_drop_element_fks','2023-05-05 09:13:49','2023-05-05 09:13:49','2023-05-05 09:13:49','e0e14667-2db3-41ff-8575-027eab9bca71'),(32,'craft','m230131_120713_asset_indexing_session_new_options','2023-05-05 09:13:49','2023-05-05 09:13:49','2023-05-05 09:13:49','0d32a20b-1fd9-4839-8b19-60de800fcff3'),(33,'craft','m230226_013114_drop_plugin_license_columns','2023-05-05 09:13:49','2023-05-05 09:13:49','2023-05-05 09:13:49','e5ba1f3c-1c6d-4583-ab73-e8e1ed5c78d5');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oeqqllimeawvorpqgkrmpcaouphrqaeiecrn` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'narrowcasting','dev-master','1.0.0','2023-05-05 08:44:59','2023-05-05 08:44:59','2023-05-05 09:13:40','d140e421-0137-48de-bb97-ac1f9a53e476'),(2,'redactor','3.0.4','2.3.0','2023-05-05 08:44:59','2023-05-05 08:44:59','2023-05-05 09:13:49','72435a7c-535a-4834-aa7b-dae0e2d2f2ef');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1683278029'),('elementSources.craft\\elements\\Asset.0.defaultSort.0','\"dateCreated\"'),('elementSources.craft\\elements\\Asset.0.defaultSort.1','\"desc\"'),('elementSources.craft\\elements\\Asset.0.disabled','false'),('elementSources.craft\\elements\\Asset.0.key','\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.0','\"filename\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.1','\"size\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.2','\"dateModified\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.3','\"link\"'),('elementSources.craft\\elements\\Asset.0.type','\"native\"'),('elementSources.craft\\elements\\Asset.1.defaultSort.0','\"dateCreated\"'),('elementSources.craft\\elements\\Asset.1.defaultSort.1','\"desc\"'),('elementSources.craft\\elements\\Asset.1.disabled','false'),('elementSources.craft\\elements\\Asset.1.key','\"folder:2776cf66-4828-4636-9707-c75a94d4ed1a\"'),('elementSources.craft\\elements\\Asset.1.tableAttributes.0','\"filename\"'),('elementSources.craft\\elements\\Asset.1.tableAttributes.1','\"size\"'),('elementSources.craft\\elements\\Asset.1.tableAttributes.2','\"dateModified\"'),('elementSources.craft\\elements\\Asset.1.tableAttributes.3','\"link\"'),('elementSources.craft\\elements\\Asset.1.type','\"native\"'),('email.fromEmail','\"alyxia@riseup.net\"'),('email.fromName','\"craft\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elementCondition','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.autocapitalize','true'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.autocomplete','false'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.autocorrect','true'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.class','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.disabled','false'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.elementCondition','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.id','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.instructions','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.label','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.max','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.min','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.name','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.orientation','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.placeholder','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.readonly','false'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.requirable','false'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.size','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.step','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.tip','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.title','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.uid','\"ec848039-61b3-4cd0-8c02-c391d2689421\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.userCondition','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.warning','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.elements.0.width','100'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.name','\"Content\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.uid','\"dca6fffc-645c-49f0-9467-0f2d5aee2a69\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.fieldLayouts.c0a16fbb-65e4-4d29-839b-b1c280941d77.tabs.0.userCondition','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.handle','\"default\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.hasTitleField','true'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.name','\"Default\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.section','\"9c11c497-5e71-4c81-afd3-317c35414085\"'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.sortOrder','1'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.titleFormat','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.titleTranslationKeyFormat','null'),('entryTypes.4e315b8e-e012-4f17-818b-a5b0c6189d80.titleTranslationMethod','\"site\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elementCondition','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.autocapitalize','true'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.autocomplete','false'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.autocorrect','true'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.class','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.disabled','false'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.elementCondition','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.id','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.instructions','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.label','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.max','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.min','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.name','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.orientation','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.placeholder','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.readonly','false'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.requirable','false'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.size','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.step','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.tip','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.title','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.uid','\"f3b2ba6d-b575-4f39-b525-17d300b870b9\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.userCondition','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.warning','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.0.width','100'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.elementCondition','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.fieldUid','\"2fe47f5e-f465-4d4b-bafc-db94fcd20d62\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.instructions','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.label','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.required','false'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.tip','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.uid','\"ef0f778b-85df-48a3-884b-c7a0a32e3d23\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.userCondition','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.warning','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.elements.1.width','100'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.name','\"Content\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.uid','\"c25aac81-6e27-41ae-a7ca-c390a8be1619\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.fieldLayouts.d159507e-00ee-4186-89ce-aa8d13c0f551.tabs.0.userCondition','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.handle','\"slides\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.hasTitleField','true'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.name','\"Slides\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.section','\"9c11c497-5e71-4c81-afd3-317c35414085\"'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.sortOrder','2'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.titleFormat','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.titleTranslationKeyFormat','null'),('entryTypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889.titleTranslationMethod','\"site\"'),('fieldGroups.9d29337f-6b3e-47b2-8ff0-aaf4151cda6d.name','\"Common\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.columnSuffix','null'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.contentColumnType','\"string\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.fieldGroup','\"9d29337f-6b3e-47b2-8ff0-aaf4151cda6d\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.handle','\"narrowcastingSlides\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.instructions','null'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.name','\"Narrowcasting Slides\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.searchable','false'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.settings.contentTable','\"{{%matrixcontent_narrowcastingslides}}\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.settings.maxBlocks','null'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.settings.minBlocks','null'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.settings.propagationKeyFormat','null'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.settings.propagationMethod','\"all\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.translationKeyFormat','null'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.translationMethod','\"site\"'),('fields.2fe47f5e-f465-4d4b-bafc-db94fcd20d62.type','\"craft\\\\fields\\\\Matrix\"'),('fs.narrowcasting.hasUrls','true'),('fs.narrowcasting.name','\"Narrowcasting\"'),('fs.narrowcasting.settings.path','\"@webroot/assets/narrowcasting\"'),('fs.narrowcasting.type','\"craft\\\\fs\\\\Local\"'),('fs.narrowcasting.url','\"@web/assets/narrowcasting\"'),('graphql.publicToken.enabled','true'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.adf70b30-6427-4956-b57f-e58fd68c05e9.isPublic','true'),('graphql.schemas.adf70b30-6427-4956-b57f-e58fd68c05e9.name','\"Public Schema\"'),('graphql.schemas.adf70b30-6427-4956-b57f-e58fd68c05e9.scope.0','\"sections.9c11c497-5e71-4c81-afd3-317c35414085:read\"'),('graphql.schemas.adf70b30-6427-4956-b57f-e58fd68c05e9.scope.1','\"entrytypes.d33c5983-4dff-4b6a-9aaa-7128c8c7c889:read\"'),('graphql.schemas.adf70b30-6427-4956-b57f-e58fd68c05e9.scope.2','\"volumes.3ed0cc78-6b93-46f3-868e-46554089d28f:read\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.field','\"2fe47f5e-f465-4d4b-bafc-db94fcd20d62\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elementCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.fieldUid','\"ce2c8583-c7bf-4d08-b9a0-cf6557c1d401\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.label','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.required','true'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.tip','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.uid','\"5d80b760-b308-4735-b3ae-a654aba3aa36\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.warning','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.0.width','100'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.fieldUid','\"9eb78600-e611-43fc-9c72-f7ee4d188cee\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.label','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.required','true'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.tip','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.uid','\"6e5de58d-c553-402a-8e60-a74642a9dfa8\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.warning','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.1.width','100'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.fieldUid','\"793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.label','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.required','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.tip','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.uid','\"990b24e3-1b70-41c6-acbc-09e00dcc4dfb\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.warning','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.2.width','100'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.elementCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.fieldUid','\"a27b6d9b-05b5-46d6-aa08-6094d75094f2\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.label','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.required','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.tip','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.uid','\"1d964b7f-09b0-4b5b-b458-512db536397c\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.userCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.warning','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.elements.3.width','100'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.name','\"Content\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.uid','\"29e65fe4-8cf0-4416-860d-04226248aedb\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fieldLayouts.a89b9c73-7077-4bce-bbe6-86a9fb3c27b5.tabs.0.userCondition','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.columnSuffix','\"jsllqrnf\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.contentColumnType','\"string(7)\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.fieldGroup','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.handle','\"backgroundColour\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.name','\"Background Colour\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.searchable','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.settings.defaultColor','\"#ffffff\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.translationKeyFormat','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.translationMethod','\"none\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0.type','\"craft\\\\fields\\\\Color\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.columnSuffix','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.contentColumnType','\"string\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.fieldGroup','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.handle','\"media\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.name','\"Media\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.searchable','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.allowedKinds','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.allowSelfRelations','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.allowSubfolders','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.allowUploads','true'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.defaultUploadLocationSource','\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.localizeRelations','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.maxRelations','1'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.minRelations','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.previewMode','\"full\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.restrictedLocationSource','\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.restrictFiles','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.restrictLocation','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.selectionLabel','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.showSiteMenu','true'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.showUnpermittedFiles','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.source','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.sources','\"*\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.targetSiteId','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.validateRelatedElements','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.settings.viewMode','\"large\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.translationKeyFormat','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.translationMethod','\"site\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.9eb78600-e611-43fc-9c72-f7ee4d188cee.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.columnSuffix','\"onvjezyq\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.contentColumnType','\"string(7)\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.fieldGroup','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.handle','\"textColour\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.name','\"Text Colour\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.searchable','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.settings.defaultColor','\"#000000\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.translationKeyFormat','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.translationMethod','\"none\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.a27b6d9b-05b5-46d6-aa08-6094d75094f2.type','\"craft\\\\fields\\\\Color\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.columnSuffix','\"btsjqgtw\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.contentColumnType','\"text\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.fieldGroup','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.handle','\"text\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.instructions','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.name','\"Text\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.searchable','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.byteLimit','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.charLimit','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.code','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.columnType','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.initialRows','4'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.multiline','false'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.placeholder','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.settings.uiMode','\"normal\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.translationKeyFormat','null'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.translationMethod','\"none\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.fields.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.handle','\"textMedia\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.name','\"Text & Media slide\"'),('matrixBlockTypes.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d.sortOrder','3'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.field','\"2fe47f5e-f465-4d4b-bafc-db94fcd20d62\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elementCondition','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.fieldUid','\"ee5459e3-ec14-4342-9e3a-fc007e6a5238\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.label','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.required','true'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.tip','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.uid','\"746ecfa6-abeb-4506-8c73-765c5537f001\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.warning','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.elements.0.width','100'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.name','\"Content\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.uid','\"a97509a6-f1c1-49e8-b31b-af26952b62e9\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fieldLayouts.a99dcfd0-e437-4f43-b3ef-3242bbcc8338.tabs.0.userCondition','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.columnSuffix','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.contentColumnType','\"string\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.fieldGroup','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.handle','\"media\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.instructions','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.name','\"Media\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.searchable','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.allowedKinds','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.allowSelfRelations','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.allowSubfolders','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.allowUploads','true'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.defaultUploadLocationSource','\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.localizeRelations','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.maxRelations','1'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.minRelations','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.previewMode','\"full\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.restrictedLocationSource','\"volume:3ed0cc78-6b93-46f3-868e-46554089d28f\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.restrictFiles','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.restrictLocation','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.0','\"conditionRules\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.0','\"class\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\FileTypeConditionRule\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.0','\"uid\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.1','\"9ed4a011-9832-4d4f-8d25-98368742d7b0\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.0','\"operator\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.1','\"in\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.0','\"values\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.1.0','\"image\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionCondition.__assoc__.3.1.0.__assoc__.3.1.1','\"video\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.selectionLabel','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.showSiteMenu','true'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.showUnpermittedFiles','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.source','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.sources','\"*\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.targetSiteId','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.validateRelatedElements','false'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.settings.viewMode','\"large\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.translationKeyFormat','null'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.translationMethod','\"site\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.fields.ee5459e3-ec14-4342-9e3a-fc007e6a5238.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.handle','\"media\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.name','\"Media slide\"'),('matrixBlockTypes.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d.sortOrder','2'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.field','\"2fe47f5e-f465-4d4b-bafc-db94fcd20d62\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elementCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.fieldUid','\"0ceb5003-324b-47f9-b336-5716ff21c825\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.label','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.required','true'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.tip','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.uid','\"31aaa4e0-fcf9-46d7-8a88-1f5a64b60ccd\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.warning','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.0.width','100'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.fieldUid','\"a7316bd8-0e45-41fb-bad7-6e74a6f2a902\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.label','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.required','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.tip','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.uid','\"375fcf49-f25e-4b97-97ca-38d23bb1ed5a\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.warning','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.1.width','100'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.elementCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.fieldUid','\"2928f6e5-130a-431d-a1f3-df296cd1f46a\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.instructions','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.label','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.required','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.tip','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.uid','\"2a098051-16ec-4052-a9f8-ce674e172a7b\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.userCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.warning','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.elements.2.width','100'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.name','\"Content\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.uid','\"c1d68812-8393-416d-8cd8-6d14a80dcc7d\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fieldLayouts.8799252d-cba1-4d22-9a19-aaa5857df6b1.tabs.0.userCondition','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.columnSuffix','\"nlujdhmf\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.contentColumnType','\"text\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.fieldGroup','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.handle','\"text\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.instructions','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.name','\"Text\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.searchable','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.byteLimit','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.charLimit','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.code','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.columnType','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.initialRows','4'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.multiline','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.placeholder','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.settings.uiMode','\"normal\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.translationKeyFormat','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.translationMethod','\"none\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.0ceb5003-324b-47f9-b336-5716ff21c825.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.columnSuffix','\"tiyqvwsy\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.contentColumnType','\"string(7)\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.fieldGroup','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.handle','\"textColour\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.instructions','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.name','\"Text Colour\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.searchable','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.settings.defaultColor','\"#000000\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.translationKeyFormat','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.translationMethod','\"none\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.2928f6e5-130a-431d-a1f3-df296cd1f46a.type','\"craft\\\\fields\\\\Color\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.columnSuffix','\"wrwllbxa\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.contentColumnType','\"string(7)\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.fieldGroup','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.handle','\"backgroundColour\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.instructions','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.name','\"Background Colour\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.searchable','false'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.settings.defaultColor','\"#ffffff\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.translationKeyFormat','null'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.translationMethod','\"none\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.fields.a7316bd8-0e45-41fb-bad7-6e74a6f2a902.type','\"craft\\\\fields\\\\Color\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.handle','\"text\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.name','\"Text slide\"'),('matrixBlockTypes.d5eac6f2-f301-4348-b212-c25460e2b3d9.sortOrder','1'),('meta.__names__.0ceb5003-324b-47f9-b336-5716ff21c825','\"Text\"'),('meta.__names__.2928f6e5-130a-431d-a1f3-df296cd1f46a','\"Text Colour\"'),('meta.__names__.2fe47f5e-f465-4d4b-bafc-db94fcd20d62','\"Narrowcasting Slides\"'),('meta.__names__.34848ad2-3bb8-49fa-8f0a-bb4f69d4881d','\"Text & Media slide\"'),('meta.__names__.3ed0cc78-6b93-46f3-868e-46554089d28f','\"Narrowcasting\"'),('meta.__names__.4e315b8e-e012-4f17-818b-a5b0c6189d80','\"Default\"'),('meta.__names__.59e177d9-17ab-4c27-8528-0f817fae7c25','\"craft\"'),('meta.__names__.793d26f5-7e0c-4d7d-9aca-51ac93b5b7e0','\"Background Colour\"'),('meta.__names__.928623f8-903d-4bb2-bb3e-c2b71c6d8b1d','\"Media slide\"'),('meta.__names__.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2','\"craft\"'),('meta.__names__.9c11c497-5e71-4c81-afd3-317c35414085','\"Narrowcasting\"'),('meta.__names__.9d29337f-6b3e-47b2-8ff0-aaf4151cda6d','\"Common\"'),('meta.__names__.9eb78600-e611-43fc-9c72-f7ee4d188cee','\"Media\"'),('meta.__names__.a27b6d9b-05b5-46d6-aa08-6094d75094f2','\"Text Colour\"'),('meta.__names__.a7316bd8-0e45-41fb-bad7-6e74a6f2a902','\"Background Colour\"'),('meta.__names__.adf70b30-6427-4956-b57f-e58fd68c05e9','\"Public Schema\"'),('meta.__names__.ce2c8583-c7bf-4d08-b9a0-cf6557c1d401','\"Text\"'),('meta.__names__.d33c5983-4dff-4b6a-9aaa-7128c8c7c889','\"Slides\"'),('meta.__names__.d5eac6f2-f301-4348-b212-c25460e2b3d9','\"Text slide\"'),('meta.__names__.ee5459e3-ec14-4342-9e3a-fc007e6a5238','\"Media\"'),('plugins.narrowcasting.edition','\"standard\"'),('plugins.narrowcasting.enabled','true'),('plugins.narrowcasting.schemaVersion','\"1.0.0\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.defaultPlacement','\"end\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.enableVersioning','true'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.handle','\"narrowcasting\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.name','\"Narrowcasting\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.propagationMethod','\"all\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.siteSettings.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.enabledByDefault','true'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.siteSettings.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.hasUrls','true'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.siteSettings.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.template','\"narrowcasting/_entry\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.siteSettings.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.uriFormat','\"narrowcasting/{slug}\"'),('sections.9c11c497-5e71-4c81-afd3-317c35414085.type','\"channel\"'),('siteGroups.59e177d9-17ab-4c27-8528-0f817fae7c25.name','\"craft\"'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.enabled','true'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.handle','\"default\"'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.hasUrls','true'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.language','\"en-US\"'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.name','\"craft\"'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.primary','true'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.siteGroup','\"59e177d9-17ab-4c27-8528-0f817fae7c25\"'),('sites.9bed703c-0031-4c03-a49d-1ca4cc0fa5a2.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"craft\"'),('system.schemaVersion','\"4.4.0.4\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elementCondition','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.autocapitalize','true'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.autocomplete','false'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.autocorrect','true'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.class','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.disabled','false'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.elementCondition','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.id','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.instructions','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.label','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.max','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.min','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.name','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.orientation','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.placeholder','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.readonly','false'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.requirable','false'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.size','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.step','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.tip','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.title','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.uid','\"b11e089d-1b17-426d-8684-cd41a2511048\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.userCondition','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.warning','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.elements.0.width','100'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.name','\"Content\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.uid','\"45efbd87-93d5-42cf-8e3a-4ad101f90169\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fieldLayouts.77272be3-f4fe-4f09-828e-8045257df5d4.tabs.0.userCondition','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.fs','\"narrowcasting\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.handle','\"narrowcasting\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.name','\"Narrowcasting\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.sortOrder','1'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.titleTranslationKeyFormat','null'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.titleTranslationMethod','\"site\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.transformFs','\"\"'),('volumes.3ed0cc78-6b93-46f3-868e-46554089d28f.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kdtrdmthggcfjkqxsyvzuhuqcgbrgotmrody` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_mfkxihokpmgvypcyjowbgqounqzhfeerechs` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sjdhnelmdyywltddtqkjvylobvthlvtsbmgt` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ulpbyqucfeieciipcnxyshhatwaxyczpzhpj` (`sourceId`),
  KEY `idx_fcwzquehkmxhmviqowcwltvuncghfrqjcnbp` (`targetId`),
  KEY `idx_vrcumgsctolevzmhkuvlhmkjnclomexayrgv` (`sourceSiteId`),
  CONSTRAINT `fk_qbhqgkxgpvzrghfbsexqiktfqialqudaveax` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tmpsbbttdbcmcafvphklthzostmvvlgdilhj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yxifvagrmouwvwfftakftvnvexpouqdoumqo` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('12f51cb0','@craft/web/assets/fileupload/dist'),('17e00f52','@craft/web/assets/garnish/dist'),('197d3fd9','@craft/web/assets/prismjs/dist'),('1ac70506','@craft/web/assets/updates/dist'),('23165a50','@craft/web/assets/dashboard/dist'),('2f78ae7b','@craft/web/assets/utilities/dist'),('38945e5','@craft/web/assets/elementresizedetector/dist'),('3f523845','@craft/web/assets/fabric/dist'),('4128db76','@craft/web/assets/editsection/dist'),('49bb9817','@craft/web/assets/axios/dist'),('50942ea7','@craft/web/assets/jquerytouchevents/dist'),('50c7f1c5','@craft/web/assets/jquerypayment/dist'),('5550f372','@craft/web/assets/velocity/dist'),('5a557c9b','@craft/web/assets/feed/dist'),('64deb94f','@craft/web/assets/iframeresizer/dist'),('654041df','@craft/web/assets/craftsupport/dist'),('6695a0d','@bower/jquery/dist'),('6724961b','@craft/web/assets/xregexp/dist'),('6c9c2b1b','@craft/web/assets/picturefill/dist'),('6fbfb0f8','@craft/web/assets/d3/dist'),('758a96b1','@craft/web/assets/cp/dist'),('79c234f9','@craft/web/assets/selectize/dist'),('7ed78edb','@craft/web/assets/tailwindreset/dist'),('8260568d','@craft/web/assets/utilities/dist'),('8abb82f4','@craft/web/assets/matrix/dist'),('924ac0b3','@craft/web/assets/fabric/dist'),('a19632ed','@craft/web/assets/jqueryui/dist'),('a27b6de8','@craft/web/assets/graphiql/dist'),('ab71a2fb','@bower/jquery/dist'),('ae91bd13','@craft/web/assets/elementresizedetector/dist'),('b7dffdf0','@craft/web/assets/updates/dist'),('baf8f7a4','@craft/web/assets/garnish/dist'),('bfede446','@craft/web/assets/fileupload/dist'),('c184d3ed','@craft/web/assets/picturefill/dist'),('c2a7480e','@craft/web/assets/d3/dist'),('c2ecb7d6','@craft/web/assets/updateswidget/dist'),('c8eca1b','@craft/web/assets/jqueryui/dist'),('c9c641b9','@craft/web/assets/iframeresizer/dist'),('ca3c6eed','@craft/web/assets/xregexp/dist'),('d3cf762d','@craft/web/assets/tailwindreset/dist'),('d4dacc0f','@craft/web/assets/selectize/dist'),('d8926e47','@craft/web/assets/cp/dist'),('e4a360e1','@craft/web/assets/axios/dist'),('f8480b84','@craft/web/assets/velocity/dist'),('fc56f5b8','@craft/web/assets/recententries/dist'),('fd8cd651','@craft/web/assets/jquerytouchevents/dist'),('fddf0933','@craft/web/assets/jquerypayment/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_raazmzghrzrylrggjappanfidftpiukzgszy` (`canonicalId`,`num`),
  KEY `fk_vmsmiysohbhvvotxryelggrnrcidvttsrbjt` (`creatorId`),
  CONSTRAINT `fk_gceowdliuwidbxjbusjjvawokjippsvirzgp` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vmsmiysohbhvvotxryelggrnrcidvttsrbjt` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,''),(2,5,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_omukbuhynsrqiwhkktmbveyevzrvofdsthoa` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' alyxia riseup net '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' alyxia '),(2,'slug',0,1,' test '),(2,'title',0,1,' test '),(5,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tzzlhweijxdtjlfrnfxsmqxinqrhqcyzdstr` (`handle`),
  KEY `idx_ldrbgxinuozglbapbakkpscivzubaacoojyo` (`name`),
  KEY `idx_hlnxwyhtcycifldodnegbxbfkgtbgavbtppo` (`structureId`),
  KEY `idx_muidyzbuacvmbjxzdvfkerqurppcjijkylty` (`dateDeleted`),
  CONSTRAINT `fk_smuemmmrasrpfpcfwrwhdqwawchbsbeuyffr` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Narrowcasting','narrowcasting','channel',1,'all','end',NULL,'2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'9c11c497-5e71-4c81-afd3-317c35414085');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zydqtdxiutgclcejzvhowcjtsxilwncfhclo` (`sectionId`,`siteId`),
  KEY `idx_yjctuppgfrmqqreegshpmwrhzalzrjbnhbfm` (`siteId`),
  CONSTRAINT `fk_jdpjijzacifapxqwpgyidkdsnlgjcdbsigcz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xidsvvhjeroiamnfvpfkaqxlxeklrbfzpkvy` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'narrowcasting/{slug}','narrowcasting/_entry',1,'2023-05-05 08:44:59','2023-05-05 08:44:59','49af86b5-0a27-447d-939f-2a8a37822478');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wzdiwopzaozeaecpzsrrmbmurrdpnwtmyszf` (`uid`),
  KEY `idx_fyimhamfyslsvxwwvvdishrcpfzoszbximag` (`token`),
  KEY `idx_zgiwfnlpntuflbiithfjqkfbqqxtovqnxnfp` (`dateUpdated`),
  KEY `idx_rafipnsisqkqfsvmoebhzktryqsjowrgfvog` (`userId`),
  CONSTRAINT `fk_esgbyxgqyqbwzxnpzovopjdhsoekvnyrhrbm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'OPebSyWF0qAe5W6MPTOdAxzovL80kJlcvWg7w5zF91b-NWvGrYRU5SwjSy-376Rdq1RfN66LCJ8RRWn-KDVO81Mia8ywELUU9rTR','2023-05-05 08:45:00','2023-05-05 09:17:01','eea5ae4d-ed05-4f04-81a0-590a4e1519b6');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xgrbqgykujrkmpxlbvuosycpxinsgrxbannx` (`userId`,`message`),
  CONSTRAINT `fk_kynhhcuelonkailefdaijkcbnxqkbghwrtmr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pmsyvhukybecyxkorogyylewlagwvmzdwphf` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'craft','2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'59e177d9-17ab-4c27-8528-0f817fae7c25');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bedemjkuheaqxlppijlpwzrejvrbgzokxywo` (`dateDeleted`),
  KEY `idx_chfswpfwachpxyrmczdgymaerzskpbepebiu` (`handle`),
  KEY `idx_tnlzwlmfbtiyoynkmymvgrrgtaatzuoxfgjx` (`sortOrder`),
  KEY `fk_giqqzsuhmhngbqzjfgkprfkcbwyjjbbcetim` (`groupId`),
  CONSTRAINT `fk_giqqzsuhmhngbqzjfgkprfkcbwyjjbbcetim` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','craft','default','en-US',1,'$PRIMARY_SITE_URL',1,'2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'9bed703c-0031-4c03-a49d-1ca4cc0fa5a2');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_afxymmdrwkeslfoomtylvrmybalddkbdedyq` (`structureId`,`elementId`),
  KEY `idx_tvbxyyfhckhyzwxqswnwzwdcfhjrugsmypll` (`root`),
  KEY `idx_vjcgisaakeqizprakgzrdkeosxbsmdprlzsi` (`lft`),
  KEY `idx_lfwsedxseyyjnsoxesrpatjbxppbnckuiahq` (`rgt`),
  KEY `idx_crlbcumcbfbuixmiziaebpiurrdrugioxvtp` (`level`),
  KEY `idx_avfmerestiyzcbzttfluefbhnkeycsyynrpa` (`elementId`),
  CONSTRAINT `fk_vonupvtvytwmcrwatdfaxaryxjjkxcirrwlc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cozohtmkgvaqeutngsbuktnuiniftbmajnve` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dmracstxmuvwyvjxyztctzrdnqbtdljwairn` (`key`,`language`),
  KEY `idx_eaqwbschwmqumzjmqgrqywtmfgfqcttwbfvj` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_goyuygxrlsyxmttjuratgjnfymbqlicmbgkz` (`name`),
  KEY `idx_ylifzdpflymrezvuvquqidbfbcrtkaimtsdi` (`handle`),
  KEY `idx_ewqepvxkttsmobzigcpmnimvogzgmjtoknad` (`dateDeleted`),
  KEY `fk_evpwakwwpkpnrurmzxpgepcjdwbdykiegsgz` (`fieldLayoutId`),
  CONSTRAINT `fk_evpwakwwpkpnrurmzxpgepcjdwbdykiegsgz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_elarmoiurwwirpuzimxukgkyzuymvrysozgj` (`groupId`),
  CONSTRAINT `fk_tftrzdshezhnlxaqysspenttefxeiefzaffe` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tkmgqksmvxsxazcskcwuncjhxqyphauzyelt` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pooppajgushukuktylqnkpcnwiaptvqmufdd` (`token`),
  KEY `idx_megjczbwiiogiylejfhzfdbkrqiofkjuwhtr` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ftpybvqefsargdjeuccabptnawfqqficlbhy` (`handle`),
  KEY `idx_wzxwuclqmyufgyipaefjvqrmvmhgjpazoujd` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wqrchbiqsiwkrjwlpvvusqzyeddxkzhoiyqt` (`groupId`,`userId`),
  KEY `idx_zbwuqutouqknnknrqqjwxrbstyoaxnnpqkbl` (`userId`),
  CONSTRAINT `fk_bnliumumqcgqdomgifdblvukqwbslvveberz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_whhfdqnfeycvadrpanwqogvbxqpnlmspqhdu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_oznicrgvyeofmkmyqskpqtsgarclhnyhbmjs` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iwotqahuuekjjovsruedmtiaybywlrhgstbd` (`permissionId`,`groupId`),
  KEY `idx_sfoecbpkkvdxoqzghnxripnqsripqwqbxzvp` (`groupId`),
  CONSTRAINT `fk_rbqdtsdyyzsbsqczhrcddychlbtjgiizzvjr` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ykhagmrjfybmckzfhznhgbzpqywiubpkgvqe` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_suzupxkfhbvhfrztkpdghzlsbvvmopxlskyq` (`permissionId`,`userId`),
  KEY `idx_xnffuhkdppzdburdhgjbcetvthltrogriysl` (`userId`),
  CONSTRAINT `fk_gmetywfddjwsixmxbymkqqemyxdqtkdddmaf` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rxjeigomiuigskgcvrislrxmaxjwbghvlzoh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_tieyvvaxayadhrvrsofsboncidduqohplpsw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zsbbfmsoznjxugrrqluxmgvwjxbaisfapvhv` (`active`),
  KEY `idx_zayvcomwoizuylxhuemrfpkpokehilcdvbqp` (`locked`),
  KEY `idx_bsxvovgjtomnlwvucfhecaiurbtdsugbwczg` (`pending`),
  KEY `idx_ptsxlioxqadouakoqfylezshijgiejxtrmuj` (`suspended`),
  KEY `idx_xkwsuccbjywgbsrsmhaypagreezndenbkzmk` (`verificationCode`),
  KEY `idx_nubabloduzrqrbunhyaonkuncwaamcyhdmwq` (`email`),
  KEY `idx_xiwyryvnoqhkuvcicatmyboztfkfpwqrkiwz` (`username`),
  KEY `fk_tgttnpwnijvgbtaygemsbgdrpdfaesugfwsf` (`photoId`),
  CONSTRAINT `fk_rmzauwbwnoemzsquyvpszjogcnfeblcvsgqa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tgttnpwnijvgbtaygemsbgdrpdfaesugfwsf` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'alyxia',NULL,NULL,NULL,'alyxia@riseup.net','$2y$13$5S2n8U1XVxGIB98DNYArQu3R4NcQX5F.FOiwxZgQ6ddyBNTipqCZW','2023-05-05 08:45:00',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2023-05-05 08:45:00','2023-05-05 08:45:00','2023-05-05 08:45:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_llwwarcpheanxvulmslqsvlmhwwubyvjfkkl` (`name`,`parentId`,`volumeId`),
  KEY `idx_kbtppevqhyfryxcoqgmlmukcurytlritkgzb` (`parentId`),
  KEY `idx_qvhwscnsvxzozcdujwohsmhnqhscowwjhpyq` (`volumeId`),
  CONSTRAINT `fk_npmlwmnrebyfbjyuighfmsfxsftruxsmkyuo` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rgvwyalfgfffhtzltitajbskqjjbezrsrwxy` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Narrowcasting',NULL,'2023-05-05 08:44:59','2023-05-05 08:44:59','88c12743-a545-4e7d-b1a1-35cb1252c045'),(2,NULL,NULL,'Temporary filesystem',NULL,'2023-05-05 08:45:41','2023-05-05 08:45:41','8d1f4dab-9dc8-4523-86a2-4e96659717f6'),(3,2,NULL,'user_1','user_1/','2023-05-05 08:45:41','2023-05-05 08:45:41','313b314b-924d-4f9f-902e-59e9e19b3032');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_chzzbqvnhfohmumizfbjpelwqpyqkgkgtjfi` (`name`),
  KEY `idx_tykewlswttkbzxpiuqvwxmzbngovudtydgvn` (`handle`),
  KEY `idx_ynwymaobjkxfxoywcfzonicgvgivhgwrfwud` (`fieldLayoutId`),
  KEY `idx_ydqgdoufdsdbrydeaecfmiorbspebdiicitx` (`dateDeleted`),
  CONSTRAINT `fk_bnxywyhcyybqqkkmnskfdvlzcsuqbtzbaueg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,3,'Narrowcasting','narrowcasting','narrowcasting','','','site',NULL,1,'2023-05-05 08:44:59','2023-05-05 08:44:59',NULL,'3ed0cc78-6b93-46f3-868e-46554089d28f');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ekxdknqsvpgrdvffbsjqrxwawzcorpfhzdrd` (`userId`),
  CONSTRAINT `fk_ybsoutzzvhvijdywtlsewyixlwykvakeqseu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-05-05 08:45:03','2023-05-05 08:45:03','fdeebf60-48d6-4090-8f3e-2c473080d93c'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-05-05 08:45:03','2023-05-05 08:45:03','b3630391-2e72-49e9-a92f-4c67b114a40f'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-05-05 08:45:03','2023-05-05 08:45:03','c6c18109-e2da-42f0-8a64-05de6c6aa166'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-05-05 08:45:03','2023-05-05 08:45:03','ef522287-bb26-4d1c-800d-b85dec064f8d');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-05  9:17:21
